package fi.lindholm.RecordApplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RecordApplicationTests {

	@Test
	void contextLoads() {
	}

}
