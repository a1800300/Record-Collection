package fi.lindholm.RecordApplication.domain;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Genre {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
		private Long genreId;
		private String name;
		
	@OneToMany(cascade = CascadeType.ALL, mappedBy = "genre") // mapped by kertoo, mikä muuttuja kyseessä record-entityluokassa
	private List<Record> records; // taulukko, koska genren alla voi olla useampi kappale
	
	public Genre() {}

	// constructor for genre name:
	public Genre(String name) {
		super();
		this.name = name;
	}

	// getters and setters for genre name:
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<Record> getRecords() {
		return records;
	}

	public void setRecords(List<Record> records) {
		this.records = records;
	}
	

	@Override
	public String toString() {
		return "Genre [genreId=" + genreId + ", name=" + name + "]";
	}
	
	

}
