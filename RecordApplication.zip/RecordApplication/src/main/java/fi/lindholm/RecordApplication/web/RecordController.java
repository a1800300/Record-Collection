package fi.lindholm.RecordApplication.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import fi.lindholm.RecordApplication.domain.GenreRepository;
import fi.lindholm.RecordApplication.domain.Record;
import fi.lindholm.RecordApplication.domain.RecordRepository;



@Controller
public class RecordController {
	@Autowired /*annotation bring repository class into the context, and
	will inject an instance of the service into the YourAppClass class.*/
	// to access the records in your database, inject repository class to your controller class.
	private RecordRepository rRepository; 
	@Autowired
	private GenreRepository grepository;

	
	// tämä sivu tulee, ellet kirjaudu sisään.
	 @RequestMapping(value={"/", "/home"})
		public String homeSecure() {
			return "home";
		}  
	    
	    @RequestMapping(value="/hello")
		public String helloSecure() {
			return "hello";
		}
	    
	    @RequestMapping(value="/login")
		public String login() {
			return "login";
		}    

 @RequestMapping(value= {"/recordlist"})
 public String recordList(Model model) {
 	// send all records to a view. This is achieved with model.
	 // toinen model genre-
     model.addAttribute("records", rRepository.findAll()); // ("key","all records from database")
   //  model.addAttribute("genres", grepository.findAll());
     return "recordlist"; // name of the view
     
 }


 @RequestMapping(value = "/add") // in addrecord.html there is a button that listens this endpoint
	public String addRecord(Model model){
 	model.addAttribute("record", new Record());
 	model.addAttribute("records", rRepository.findAll());
    model.addAttribute("genre", grepository.findAll());
     return "addrecord"; // goes to addrecord.html
 }     
 
 @RequestMapping(value = "/save", method = RequestMethod.POST) // addrecord needs a submit endpoint /save
 public String save(Record record){
     rRepository.save(record);
     return "redirect:recordlist"; // goes to recordlist.html
 } 
 

 @RequestMapping(value = "/delete/{id}", method = RequestMethod.GET) //{id} is the path variable. you can delete by localhost/8080/idnumber
 public String deleteRecord(@PathVariable("id") Long recordId, Model model) { // saves it to the variable recordId
 	rRepository.deleteById(recordId);
     return "redirect:../recordlist";
 }  
 
//Edit record
@RequestMapping(value = "/edit/{id}")
public String addRecord(@PathVariable("id") Long recordId, Model model){
model.addAttribute("record", rRepository.findById(recordId));
model.addAttribute("genre", grepository.findAll());
return "editrecord";
}
}



//In a typical Spring application, Controller classes are responsible for
//preparing a model map with data and selecting a view to be rendered.

