package fi.lindholm.RecordApplication;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;


import fi.lindholm.RecordApplication.domain.Genre;
import fi.lindholm.RecordApplication.domain.GenreRepository;
import fi.lindholm.RecordApplication.domain.Record;
import fi.lindholm.RecordApplication.domain.RecordRepository;




@SpringBootApplication
public class RecordApplication {

	public static void main(String[] args) {
		SpringApplication.run(RecordApplication.class, args);
	}
	
	@Bean
	public CommandLineRunner RecordAppDemo (RecordRepository rRepository, GenreRepository grepository) {
		return (args) -> {
		//Log.info("save a couple of Records");
		
			// Tallennetaan kirjoja valmiiksi tämän komentorivin kautta, jotta ohjelman demoaminen ja muokkaus helpompaa:
	/* Attribuutit: 		this.artist = artist;
		this.title = title;
		this.length = length;
		this.genre = genre;
		this.year = year;*/
			
			grepository.save(new Genre("Breaks"));
			grepository.save(new Genre("Electro"));
			grepository.save(new Genre("Hip Hop"));
			
			rRepository.save(new Record("Joy Orbison","Burn","Slipping","5:30",grepository.findByName("Breaks").get(0),2019));
			rRepository.save(new Record("Morphology","Vector Plant","Finnish Electro All-Star","5:24",grepository.findByName("Electro").get(0),2016));
		//	Record r3 = new Record ();
						
			//	repository.save(r4);
			//	repository.save(r5);
			//	repository.save(r3);
			
			//}
			// Create users: admin/admin user/user


			

		};
	}


}
