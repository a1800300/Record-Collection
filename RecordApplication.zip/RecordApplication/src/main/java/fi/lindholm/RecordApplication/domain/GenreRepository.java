package fi.lindholm.RecordApplication.domain;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

//crud repository is a ready JPA interface. Inside <> we define the duties of the interface: What Entity does this BookRepository belong to?
public interface GenreRepository extends CrudRepository <Genre, Long> {

List<Genre> findByName(String name);

//<title extends Record> S save(S Record);
	//void deleteById(Long id);



	//Object findAll();

	/*@Repository is a Spring annotation that indicates that the decorated class is a repository. 
	A repository is a mechanism for
	encapsulating storage, retrieval, and search behavior which emulates a collection of objects
*/


}